// CKEditor  - Rock-solid, free WYSIWYG editor with collaborative editing, 200+ features, full documentation and support: https://ckeditor.com/

// CKEditor Decoupled Editor
window.DecoupledEditor = require('@ckeditor/ckeditor5-build-decoupled-document/build/ckeditor.js');
